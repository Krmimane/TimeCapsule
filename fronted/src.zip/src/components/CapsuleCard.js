import React, { useState } from "react";
import "../styles/CapsuleCard.css";

const CapsuleCard = ({ capsule, onLike, onComment }) => {
  const [reactions, setReactions] = useState(() => {
    const savedReactions = localStorage.getItem(`capsule-${capsule.id}-reactions`);
    return savedReactions ? JSON.parse(savedReactions) : capsule.reactions || [];
  });

  const [commentText, setCommentText] = useState("");
  const [showComments, setShowComments] = useState(false);

  const saveReactions = (updatedReactions) => {
    localStorage.setItem(`capsule-${capsule.id}-reactions`, JSON.stringify(updatedReactions));
  };

  const handleLike = () => {
    const hasLiked = reactions.some((reaction) => reaction.type === "like" && reaction.user_id === 1);

    if (hasLiked) {
      const updatedReactions = reactions.filter(
        (reaction) => !(reaction.type === "like" && reaction.user_id === 1)
      );
      setReactions(updatedReactions);
      saveReactions(updatedReactions);
      console.log("Like removed.");
    } else {
      if (typeof onLike === "function") {
        onLike(capsule.id);
      }
      const updatedReactions = [...reactions, { type: "like", user_id: 1 }];
      setReactions(updatedReactions);
      saveReactions(updatedReactions);
      console.log("Like added.");
    }
  };

  const handleAddComment = () => {
    if (commentText.trim()) {
      if (typeof onComment === "function") {
        onComment(capsule.id, commentText);
      }
      const updatedReactions = [
        ...reactions,
        { type: "comment", user_id: 1, comment_text: commentText },
      ];
      setReactions(updatedReactions);
      saveReactions(updatedReactions);
      setCommentText("");
    }
  };

  return (
    <div className="capsule-card-theme25">
      <div className="capsule-header25">
        <img
          src={(capsule.user && capsule.user.profilePicture) || "https://static.vecteezy.com/system/resources/previews/005/544/718/non_2x/profile-icon-design-free-vector.jpg"}
          alt={(capsule.user && capsule.user.name) || "User"}
          className="capsule-profile-picture25"
        />
        <div className="capsule-user-info25">
          <h3 className="capsule-user-name25">{capsule.user.name || "Unknown User"}</h3>
          <p className="capsule-user-username25">@{capsule.user.username || "username"}</p>
        </div>
      </div>

      <div className="capsule-content25">
        <h3 className="capsule-title25">{capsule.title || "Untitled Capsule"}</h3>
        <p className="capsule-description25">{capsule.description || "No description available."}</p>
      </div>

      <div className="capsule-buttons25">
        <button className="button-icon25" onClick={handleLike}>
          ❤️ {reactions.some((r) => r.type === "like" && r.user_id === 1) ? "Unlike" : "Like"} (
          {reactions.filter((r) => r.type === "like").length})
        </button>
        <button
          className="button-icon25"
          onClick={() => setShowComments(!showComments)}
        >
          💬 Comment ({reactions.filter((r) => r.type === "comment").length})
        </button>
      </div>

      {showComments && (
        <div className="comments-section25">
          <div className="comments-list25">
            {reactions
              .filter((reaction) => reaction.type === "comment")
              .map((reaction, index) => (
                <p key={index} className="comment25">{reaction.comment_text}</p>
              ))}
          </div>
          <div className="add-comment25">
            <input
              type="text"
              className="comment-input25"
              placeholder="Add a comment"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
            />
            <button className="comment-button25" onClick={handleAddComment}>
              Submit
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CapsuleCard;
