import React from "react";
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
/>

export const Services = () => {
  return (
    <div id="services" className="text-center">
      <div className="container">
        <div className="section-title">
          <h2>Our Services</h2>
          <p>
            We offer unique and personalized services to help you preserve your most cherished memories for the future.
          </p>
        </div>
        <div className="row">
          <div className="col-md-4">
            <i className="fa fa-box"></i> {/* Icône boîte pour Create Your Capsule */}
            <div className="service-desc">
              <h3>Create Your Capsule</h3>
              <p>
                Create a personalized time capsule where you can store messages, photos, and videos to be revealed at a later date.
              </p>
            </div>
          </div>
          <div className="col-md-4">
            <i className="fa fa-lock"></i>
            <div className="service-desc">
              <h3>Secure Storage</h3>
              <p>
                Your memories are securely stored and encrypted to ensure they remain private and protected until the designated time.
              </p>
            </div>
          </div>
          <div className="col-md-4">
            <i className="fa fa-calendar"></i>
            <div className="service-desc">
              <h3>Scheduled Release</h3>
              <p>
                Choose a specific date or event in the future to unlock and share your time capsule, creating a memorable moment.
              </p>
            </div>
          </div>
          <div className="col-md-4">
            <i className="fa fa-camera-retro"></i>
            <div className="service-desc">
              <h3>Photo and Video Upload</h3>
              <p>
                Upload your favorite photos and videos to create a visually engaging time capsule that will be cherished for years to come.
              </p>
            </div>
          </div>
          <div className="col-md-4">
            <i className="fa fa-pencil-alt"></i> {/* Icône stylo pour Personalized Messages */}
            <div className="service-desc">
              <h3>Personalized Messages</h3>
              <p>
                Write heartfelt letters and messages that will be revealed to your loved ones in the future, making your time capsule even more meaningful.
              </p>
            </div>
          </div>
          <div className="col-md-4">
            <i className="fa fa-share-alt"></i>
            <div className="service-desc">
              <h3>Share with Others</h3>
              <p>
                Allow friends and family to contribute to your time capsule, creating a shared experience that grows over time.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
