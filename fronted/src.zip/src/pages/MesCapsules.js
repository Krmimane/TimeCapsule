import React, { useEffect, useState } from "react";
import api from "../axiosConfig"; // Adaptez le chemin selon votre projet
import "../styles/mescapsule.css";
const MesCapsules = () => {
  const [waitingCapsules, setWaitingCapsules] = useState([]);
  const [readyCapsules, setReadyCapsules] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCapsuleDetails = async (capsuleId) => {
    try {
      const capsuleResponse = await api.get(`/capsules/${capsuleId}`);
      const userResponse = await api.get(`/users/${capsuleResponse.data.user_id}`);
      const contentResponse = await api.get(`/capsules/${capsuleId}/contents`);

      return {
        capsule: capsuleResponse.data,
        user: userResponse.data,
        contents: contentResponse.data,
      };
    } catch (error) {
      console.error("Erreur lors de la récupération des détails de la capsule", error);
    }
  };
  useEffect(() => {
    const fetchCapsules = async () => {
      try {
        const waitingResponse = await api.get("/user/capsulesattente");
        const readyResponse = await api.get("/user/capsulesready");

        const waitingCapsulesData = await Promise.all(
          waitingResponse.data.map(async (capsule) => {
            const details = await fetchCapsuleDetails(capsule.id);
            return { ...capsule, user: details.user, contents: details.contents };
          })
        );
        const readyCapsulesData = await Promise.all(
          readyResponse.data.map(async (capsule) => {
            const details = await fetchCapsuleDetails(capsule.id);
            return { ...capsule, user: details.user, contents: details.contents };
          })
        );

        setWaitingCapsules(waitingCapsulesData);
        setReadyCapsules(readyCapsulesData);
      } catch (error) {
        console.error("Erreur lors de la récupération des capsules", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCapsules();
  }, []);

  const handleCardClick = (e) => {
    const card = e.currentTarget;
    card.classList.toggle("active");
  };

  if (loading) {
    return <div>Chargement...</div>;
  }

  return (
    <div className="capsules-container">
      <h1>Mes Capsules</h1>
      
      <section>
        <h2>Capsules Prêtes à Ouvrir</h2>
        <div className="capsules-list">
          {readyCapsules.map((capsule) => (
            <div
              key={capsule.id}
              className="card"
              onClick={handleCardClick} // Ajout du gestionnaire de clic
            >
              <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 5H4V19L13.2923 9.70649C13.6828 9.31595 14.3159 9.31591 14.7065 9.70641L20 15.0104V5ZM2 3.9934C2 3.44476 2.45531 3 2.9918 3H21.0082C21.556 3 22 3.44495 22 3.9934V20.0066C22 20.5552 21.5447 21 21.0082 21H2.9918C2.44405 21 2 20.5551 2 20.0066V3.9934ZM8 11C6.89543 11 6 10.1046 6 9C6 7.89543 6.89543 7 8 7C9.10457 7 10 7.89543 10 9C10 10.1046 9.10457 11 8 11Z"></path>
              </svg>
              <div className="card__content">
              <div className="card-header">
                <img
                  src={capsule.user.profile_picture || "/path/to/default-image.jpg"}
                  alt={capsule.user.name}
                  className="profile-picture"
                />
                <h3 className="capsule-title">{capsule.title}</h3>
              </div>

                <p className="card__description">{capsule.description}</p>
                <div className="capsule-contents">
                {capsule.contents.map((content, index) => (
                  <div key={index} className="content">
                    <p>{content.text}</p>
                  </div>
                ))}
              </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2>Capsules En Attente</h2>
        <div className="capsules-list">
          {waitingCapsules.map((capsule) => (
            <div
              key={capsule.id}
              className="card disabled"
              onClick={handleCardClick} // Ajout du gestionnaire de clic
            >
              <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 5H4V19L13.2923 9.70649C13.6828 9.31595 14.3159 9.31591 14.7065 9.70641L20 15.0104V5ZM2 3.9934C2 3.44476 2.45531 3 2.9918 3H21.0082C21.556 3 22 3.44495 22 3.9934V20.0066C22 20.5552 21.5447 21 21.0082 21H2.9918C2.44405 21 2 20.5551 2 20.0066V3.9934ZM8 11C6.89543 11 6 10.1046 6 9C6 7.89543 6.89543 7 8 7C9.10457 7 10 7.89543 10 9C10 10.1046 9.10457 11 8 11Z"></path>
              </svg>
              <div className="card__content">
              <div className="card-header">
                <img
                  src={capsule.user.profile_picture || "/path/to/default-image.jpg"}
                  alt={capsule.user.name}
                  className="profile-picture"
                />
                <h3 className="capsule-title">{capsule.title}</h3>
              </div>
              
                <p className="card__description">Cette capsule est encore en attente.</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default MesCapsules;
